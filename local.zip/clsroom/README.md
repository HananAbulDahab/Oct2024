# Local clsroom

This is a clsroom plugin for moodle. It will collect clsroom info and allows admins to create them.



## Functionality
- Form for admins to add new clsroom
