<?php

/**
 * Unit tests for local_clsroom
 *
 * @package    local_clsroom
 * @category   phpunit
 */

defined('MOODLE_INTERNAL') || die();

use local_clsroom\manager;
global $CFG;
require_once($CFG->dirroot . '/local/clsroom/lib.php');

class local_clsroom_manager_test extends advanced_testcase
{
    /**
     * Test that we can create a clsroom.
     */
    public function test_create_clsroom() {
        $this->resetAfterTest();
        $this->setUser(2);
        $manager = new manager();
        $clsrooms = $manager->get_clsrooms(2);
        $this->assertEmpty($clsrooms);

        //$type = \core\output\notification::NOTIFY_SUCCESS;
        $result = $manager->create_clsroom('Test clsroom', $type);

        $this->assertTrue($result);
        $clsrooms = $manager->get_clsrooms(2);
        $this->assertNotEmpty($clsrooms);

        $this->assertCount(1, $clsrooms);
        $clsroom = array_pop($clsrooms);

        $this->assertEquals('Test clsroom', $clsroom->clsroomtext);
        //$this->assertEquals($type, $clsroom->clsroomtype);
    }

    /**
     * Test that we get the correct clsrooms.
     */
    public function test_get_clsrooms() {

        global $DB;
        $this->resetAfterTest();
        $this->setUser(2);
        $manager = new manager();

        //$type = \core\output\notification::NOTIFY_SUCCESS;
        //$manager->create_clsroom('Test clsroom1', $type);
        //$manager->create_clsroom('Test clsroom2', $type);
        //$manager->create_clsroom('Test clsroom3', $type);

        $clsrooms = $DB->get_records('local_clsroom');

        foreach ($clsrooms as $id => $clsroom) {
            $manager->mark_clsroom_read($id, 1);
        }

        $clsroomsAdmin = $manager->get_clsrooms(2);
        $this->assertCount(3, $clsroomsAdmin);

        foreach ($clsrooms as $id => $clsroom) {
            $manager->mark_clsroom_read($id, 2);
        }

        $clsroomsAdmin = $manager->get_clsrooms(2);
        $this->assertCount(0, $clsroomsAdmin);
    }
}
