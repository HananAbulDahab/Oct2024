<?php

/**
 * @package     local_clsroom
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @var stdClass $plugin
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_clsroom';
$plugin->version = 2020071903;
$plugin->requires = 2016052300; // Moodle version
