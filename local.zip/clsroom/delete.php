<?php

/**
 * @package     local_clsroom
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

use local_clsroom\form\edit;
use local_clsroom\manager;

require_once(__DIR__ . '/../../config.php');

require_login();
$context = context_system::instance();
require_capability('local/clsroom:manageclsrooms', $context);

$PAGE->set_url(new moodle_url('/local/clsroom/edit.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title('Edit');

$clsroomid = optional_param('clsroomid', null, PARAM_INT);

// We want to display our form.
$mform = new edit();

if ($mform->is_cancelled()) {
    // Go back to manage.php page
    redirect($CFG->wwwroot . '/local/clsroom/manage.php', get_string('cancelled_form', 'local_clsroom'));

} else if ($fromform = $mform->get_data()) {
    $manager = new manager();
    
    if ($fromform->id ) {
        // We are updating an existing clsroom.
        $manager->updatedel_clsroom($fromform->id, $fromform->clsroomtext, $fromform->clsroomaddress);
        redirect($CFG->wwwroot . '/local/clsroom/manage.php', get_string('updated_form', 'local_clsroom') . $fromform->clsroomtext);
    }
    
    //$manager->create_clsroom($fromform->clsroomtext, $fromform->clsroomaddress);

    // Go back to manage.php page
    //redirect($CFG->wwwroot . '/local/clsroom/manage.php', get_string('created_form', 'local_clsroom') . $fromform->clsroomtext);
}

if ($clsroomid) {
    // Add extra data to the form.
    global $DB;
    $manager = new manager();
    $clsroom = $manager->get_clsroom($clsroomid);
    if (!$clsroom) {
        throw new invalid_parameter_exception('clsroom not found');
    }
    $mform->set_data($clsroom);
}

echo $OUTPUT->header();
$mform->display();
echo $OUTPUT->footer();
