<?php
/**
 * @package     local_clsroom
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_clsroom\form;
use moodleform;

require_once("$CFG->libdir/formslib.php");

class edit extends moodleform {
    //Add elements to form
    public function definition() {
        global $CFG;
        $mform = $this->_form; // Don't forget the underscore!

        $mform->addElement('hidden', 'id');
        $mform->setType('id', PARAM_INT);
        
          
        $mform->addElement('text', 'clsroomtext', get_string('clsroom_text', 'local_clsroom')); // Add elements to your form
        $mform->setType('clsroomtext', PARAM_NOTAGS);                   //Set type of element
        $mform->setDefault('clsroomtext', get_string('enter_clsroom', 'local_clsroom'));        //Default value

        //$choices = array();
        //$choices['0'] = \core\output\notification::NOTIFY_WARNING;
        //$choices['1'] = \core\output\notification::NOTIFY_SUCCESS;
        //$mform->addElement('select', 'clsroomtype', get_string('clsroom_type', 'local_clsroom'), $choices);
        //$mform->setDefault('clsroomtype', '1');
        $mform->addElement('text', 'clsroomaddress', get_string('clsroom_address', 'local_clsroom')); // Add elements to your form
        $mform->setType('clsroomaddress', PARAM_NOTAGS);                   //Set type of element
        $mform->setDefault('clsroomaddress', get_string('enter_address', 'local_clsroom'));        //Default value

        $this->add_action_buttons();
    }
    //Custom validation should be added here
    function validation($data, $files) {
        return array();
    }
}
