<?php

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */
require_once(__DIR__ . '/../../config.php');

global $USER;
global $DB, $CFG;
if($USER->id != null){
    echo "not NULL";
    $userId=$USER->id;
    if($userId != null){
        echo "2. not NULL";
    }
}else{
    echo "NULL";
    $userId=$USER->id;
    if($userId == null){
        echo "2. NULL";
    }
}
echo "--" . $USER->id . "--";
