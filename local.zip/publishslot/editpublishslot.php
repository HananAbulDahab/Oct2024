<?php

/**
 * @package     local_publishslot
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

//use local_machine\form\editcookies;
//use local_machine\manager;

require_once(__DIR__ . '/../../config.php');

require_login();
$context = context_system::instance();

//require_capability('local/mancookies:managemancookies', $context);

$PAGE->set_url(new moodle_url('/local/publishslot/editpublishslot.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title('publish slot');

$courseid = optional_param('course', null, PARAM_INT);//id
$schedulerid = optional_param('id', null, PARAM_INT);//schedulerid
$slotsArray = array();
// We want to display our form.
//    $manager = new manager();
$courseId =$courseid;
    //echo  "userId-"  . $userId  . "userId-"  . $id;
$rsslots = $DB->get_recordset_sql('select id from mdl_scheduler_slots where schedulerid=' . $schedulerid);
$slotindex=0;   
foreach($rsslots as $rsst) {
            $key2 = $slotindex;
            $value2 = $rsst->id;
            
            $slotsArray[$key2] = $value2;
            $slotindex=$slotindex+1;
}
$index=0;
    //$userId = $mform->userid;//optional_param('id', $USER->id, PARAM_INT);    // User id.
$rs = $DB->get_recordset_sql('select id from mdl_groups where courseid=' . $courseId);

        foreach ($rs as $groupid) {
            $recordsfound = true;
            $rsgm = $DB->get_recordset_sql('select userid from mdl_groups_members where groupid=' . $groupid->id);
            foreach ($rsgm  as $genuserid) {
                $userId=$genuserid->userid;
                //echo '>>>>field id>' . $fieldid . ">>>";
                //$user = $DB->get_record('user_info_data', ['userid' =>  $userId , 'fieldid' =>  $validationkeyid]);
                //insert scheduler_appointment
                $data = new \stdClass();   
                
                $data->studentid=$userId;
                $data->slotid=$slotsArray[$index];
                
                $data->teachernoteformat =0;
                $data->studentnoteformat=0;
                $data->appointmentnoteformat=0;
                $data->attended =0;
                
                $DB->insert_record('scheduler_appointment', $data, $bulk=false);
                
                if($slotindex > $index){
                    $index=$index+1;
                }
                    
            }
            
            
        }


      //create records for teachers
        
        //$committee = $DB->get_record('local_committee', ['schedulerid' =>  $schedulerid ]);
        //$committeeid=$committee->id;
       
        //$rsteacher = $DB->get_recordset_sql('select u.id as id from mdl_user u, mdl_enrol e, mdl_user_enrolments ue, mdl_role_assignments ra where ue.userid=u.id and ue.enrolid=e.id and e.courseid='.  $courseId .' and ra.userid=u.id and ra.roleid=3 and ra.contextid=2');
            
        //foreach ($rsteacher  as $rsteacherid) {
        //    $teacherid=$rsteacherid->id;
        //
        //    $data1 = new \stdClass();   
                
        //    $data1->committeeid=$committeeid;
        //    $data1->teacherid=$teacherid;
            
        //    $DB->insert_record('local_committee_teacher', $data1, $bulk=false);
       //}

    // Go back to manage.php page
redirect($CFG->wwwroot . '/local/publishslot/manage.php');
///}


//echo $OUTPUT->header();
//$mform->display();
//echo $OUTPUT->footer();
