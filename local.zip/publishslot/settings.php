<?php

if ($hassiteconfig) { // needs this condition or there is error on login page

    $ADMIN->add('localplugins', new admin_category('local_publishslot_category', get_string('pluginname', 'local_publishslot')));

    $settings = new admin_settingpage('local_publishslot', get_string('pluginname', 'local_publishslot'));
    $ADMIN->add('local_publishslot_category', $settings);

    $settings->add(new admin_setting_configcheckbox('local_publishslot/enabled',
        get_string('setting_enable', 'local_publishslot'), get_string('setting_enable_desc', 'local_publishslot'), '1'));

    $ADMIN->add('local_publishslot_category', new admin_externalpage('local_publishslot_manage', get_string('manage', 'local_publishslot'),
        $CFG->wwwroot . '/local/publishslot/manage.php'));
}
