<?php

/**
 * @package     local_publishslot
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

global $DB;

require_login();
$context = context_system::instance();

require_capability('local/publishslot:managepublishslot', $context);

$PAGE->set_url(new moodle_url('/local/publishslot/manage.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title(get_string('manage_publishslot', 'local_publishslot'));
$PAGE->set_heading(get_string('manage_publishslot', 'local_publishslot'));
$PAGE->requires->js_call_amd('local_publishslot/confirm');
$PAGE->requires->css('/local/publishslot/styles.css');

$gencourses = $DB->get_records('scheduler', null, 'id');

echo $OUTPUT->header();
$templatecontext = (object)[
    'publishslot' => array_values($gencourses),
    'editurl' => new moodle_url('/local/publishslot/editpublishslot.php'),
    
];

echo $OUTPUT->render_from_template('local_publishslot/manage', $templatecontext);

echo $OUTPUT->footer();
