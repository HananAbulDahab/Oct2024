<?php

/**
 * @package     local_postmansms
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

//use local_machine\form\editcookies;
//use local_machine\manager;

require_once(__DIR__ . '/../../config.php');

require_login();
$context = context_system::instance();

//require_capability('local/mancookies:managemancookies', $context);

$PAGE->set_url(new moodle_url('/local/postmansms/editpostmansms.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title('postman sms');

$field = $DB->get_record('user_info_field', ['shortname' =>  'validationkey']);
$validationkeyid=$field->id;

$gencourseid = optional_param('id', null, PARAM_INT);
$gencourseId =$gencourseid;
$rs = $DB->get_recordset_sql('select grp.id as id, qu.name as name, qu.timelimit as timelimit, qu.timeopen as timeopen from mdl_quiz as qu, mdl_groups as grp where qu.course=grp.courseid and grp.courseid=' . $gencourseId);
try{
    foreach ($rs as $gengroupid) {
        $recordsfound = true;
        $rsgm = $DB->get_recordset_sql('select gm.userid as userid, grp.name as grpname, grp.description, grp.id as grpid from mdl_groups_members as gm, mdl_groups as grp  where grp.id=gm.groupid and gm.groupid=' . $gengroupid->id);
        $msgStrGrp="Quiz: " . $gengroupid->name . ", -Start: " . date('H:i:s d-M-Y',$gengroupid->timeopen) . ", -duratin: " . ($gengroupid->timelimit)/60 . "min**---\n\t";
        foreach ($rsgm  as $genuserid) {
            $msgStrGrp=$msgStrGrp . "Class(group):" . $genuserid->grpname . "\n\t";
            $userId=$genuserid->userid;
            $grpusermember=$DB->get_recordset_sql('select u.phone1 as phone1, u.username as userusername, u.firstname as userfirstname, u.lastname as userlastname, d.data as seatno from mdl_user as u, mdl_user_info_data as d  where d.userid=u.id and d.userid=' . $userId . ' and d.fieldid=' . $validationkeyid);
            foreach ($grpusermember  as $grpuser) {
                $msgStr=$msgStrGrp ."ID:" . $userId . "\n\t";
                $msgStr=$msgStr . "To:" . $grpuser->phone1 . "\n\t";
                $msgStr=$msgStr . "Name:" . $grpuser->userfirstname;
                $msgStr=$msgStr . " " . $grpuser->userlastname . "\n\t";
                $msgStr=$msgStr . "userName:" . $grpuser->userusername . "\n\t";
                $msgStr=$msgStr . "seat no.:" . $grpuser->seatno . "\n\t";
                $dataobject = new stdClass();
                $dataobject->userid=$userId;
                $dataobject->msgbody=$msgStr;
                $dataobject->tophone1=$grpuser->phone1;
                $dataobject->flag=0;   
                $dataobject->trials=0;  
                $dataobject->timesent=0;
                $dataobject->resultvalue="";
                $DB->insert_record('local_postmansms',$dataobject,true,$bulk = false);
                //echo "<br>-" . $msgStr; 
            }
         
        }
    }
}catch(Exception $e){
    echo $e;
 }
//should be return to manage   
redirect($CFG->wwwroot . '/local/postmansms/manage.php');
