<?php

/**
 * Plugin strings are defined here.
 *
 * @package     local_postmansms
 * @category    string
 * @copyright   2024 iqraa <iqraa@iqraa.edu>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Generate sms';

//$string['pluginname'] = 'genseatno';
$string['manage'] = 'Generate sms';
$string['setting_enable'] = 'Enable';
$string['setting_enable_desc'] = 'Disable to stop ';
$string['postmansms:view'] = 'Generate sms';
$string['manage_postmansms'] = 'Generate sms';



$string['genseatno:managepostmansms'] = 'Generate sms';


