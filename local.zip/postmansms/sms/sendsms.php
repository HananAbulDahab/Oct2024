<?php
require_once(__DIR__ . '/../../../config.php');

global $DB;


// Load JSON data from file
$jsonData = file_get_contents('sms_data.json');
$smsData = json_decode($jsonData, true);

// Extract data from the JSON
$senderId = $smsData['senderId'];
$accName = $smsData['accName'];
$accPass = $smsData['accPass'];
$id = $smsData['id'];

$rsmsg = $DB->get_recordset_sql('select * from mdl_local_postmansms where flag=0');
    
foreach($rsmsg as $getmsg){
    $numbers = $getmsg->tophone1;
    $msg = $getmsg->msgbody;
    // Buid the URL
    $url = "https://josmsservice.com/SMSServices/Clients/Prof/SingleSMS/SMSService.asmx/SendSMS?senderid={$senderId}&accname={$accName}&AccPass={$accPass}&id={$id}&numbers={$numbers}&msg=" . urlencode($msg);
    // Send the request using cURL
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    if ($response !== false) {
        echo "SMS sent successfully: " . $response;
        $resflag=3;//3==sent success 
    } else {
        echo "Failed to send SMS: " . curl_error($ch);
        $resflag=2;//2==error
    }
    curl_close($ch);
    $getmsg->flag=$resflag;
    $getmsg->resultvalue=$response;
    $DB->update_record('local_postmansms', $getmsg, $bulk=false);

}