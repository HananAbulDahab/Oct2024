<?php

/**
 * @package     local_committee
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

use local_committee\form\edit;
use local_committee\manager;

require_once(__DIR__ . '/../../config.php');

require_login();
$context = context_system::instance();
require_capability('local/committee:managecommittee', $context);

$PAGE->set_url(new moodle_url('/local/committee/edit.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title('Edit');

$committeeid = optional_param('committeeid', null, PARAM_INT);

// We want to display our form.
$mform = new edit();

if ($mform->is_cancelled()) {
    // Go back to manage.php page
    redirect($CFG->wwwroot . '/local/committee/manage.php', get_string('cancelled_form', 'local_committee'));

} else if ($fromform = $mform->get_data()) {
    $manager = new manager();
    if ($fromform->id ) {
        // We are updating an existing clsroom.
        $manager->update_committee($fromform->id, $fromform->committeetype, $fromform->memberscount, $fromform->clsroomid, $fromform->schedulerid);
        redirect($CFG->wwwroot . '/local/committee/manage.php', get_string('updated_form', 'local_committee') . $fromform->committeetype);
    }
    
    $manager->create_committee($fromform->committeetype, $fromform->memberscount, $fromform->clsroomid, $fromform->schedulerid);

    // Go back to manage.php page
    redirect($CFG->wwwroot . '/local/committee/manage.php', get_string('created_form', 'local_committee') . $fromform->committeetype);
}

if ($committeeid) {
    // Add extra data to the form.
    global $DB;
    $manager = new manager();
    $committee = $manager->get_committee($committeeid);
    if (!$committee) {
        throw new invalid_parameter_exception('committee not found');
    }
    $mform->set_data($committee);
}

echo $OUTPUT->header();
$mform->display();
echo $OUTPUT->footer();
