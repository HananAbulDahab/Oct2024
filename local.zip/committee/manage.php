<?php

/**
 * @package     local_committee
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../config.php');

global $DB;

require_login();
$context = context_system::instance();
require_capability('local/committee:managecommittee', $context);

$PAGE->set_url(new moodle_url('/local/committee/manage.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title(get_string('manage_committee', 'local_committee'));
$PAGE->set_heading(get_string('manage_committee', 'local_committee'));
$PAGE->requires->js_call_amd('local_committee/confirm');
$PAGE->requires->css('/local/committee/styles.css');

$committees = $DB->get_records('local_committee',  ['delflag' => 0], 'id');

echo $OUTPUT->header();
$templatecontext = (object)[
    'committee' => array_values($committees),
    'editurl' => new moodle_url('/local/committee/edit.php'),
    'deleteurl' => new moodle_url('/local/committee/delete.php'),
    
];

echo $OUTPUT->render_from_template('local_committee/manage', $templatecontext);

echo $OUTPUT->footer();
