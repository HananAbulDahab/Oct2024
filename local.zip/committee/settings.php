<?php

if ($hassiteconfig) { // needs this condition or there is error on login page

    $ADMIN->add('localplugins', new admin_category('local_committee_category', get_string('pluginname', 'local_committee')));

    $settings = new admin_settingpage('local_committee', get_string('pluginname', 'local_committee'));
    $ADMIN->add('local_committee_category', $settings);

    $settings->add(new admin_setting_configcheckbox('local_committee/enabled',
        get_string('setting_enable', 'local_committee'), get_string('setting_enable_desc', 'local_committee'), '1'));

    $ADMIN->add('local_committee_category', new admin_externalpage('local_committee_manage', get_string('manage', 'local_committee'),
        $CFG->wwwroot . '/local/committee/manage.php'));
}
