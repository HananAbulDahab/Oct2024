<?php
/**
 * @package     local_committee
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_committee\form;
use moodleform;
use dml_exception;
use stdClass;

require_once("$CFG->libdir/formslib.php");
require_once(__DIR__ . '/../../../../config.php');


class edit extends moodleform {
    //Add elements to form
    public function definition() {
        global $CFG;
        global $DB;

        $mform = $this->_form; // Don't forget the underscore!

        $mform->addElement('hidden', 'id');
        $mform->setType('id', PARAM_INT);
        
          
        $mform->addElement('text', 'memberscount', get_string('committee_members', 'local_committee')); // Add elements to your form
        $mform->setType('memberscount', PARAM_NOTAGS);                   //Set type of element
        $mform->setDefault('memberscount', get_string('memberscount', 'local_committee'));        //Default value

        $choices = array();
        $choices['0'] = "Initial Screening";
        $choices['1'] = "Technical";
        $choices['2'] = "Behavioral";
        $choices['3'] = "Cultural Fit";
        $choices['4'] = "Problem Solving";
        $choices['5'] = "Experience-Based";
        
        $mform->addElement('select', 'committeetype', get_string('committeetype', 'local_committee'), $choices);
        
        $mform->setDefault('committeetype', '0');
        $mform->addElement('text', 'committeetype', get_string('committeetype', 'local_committee')); // Add elements to your form
        
        $rs = $DB->get_recordset_sql('select * from mdl_local_clsroom where delflag=0');
    
        $selectArray = array();
       
      // push query results into selectArray as key, value
        foreach($rs as $rsclsid) {
            $key = $rsclsid->id;
            $value = $rsclsid->clsroomtext;
            $selectArray[$key] = $value;
        }

        //$mform->addElement('select', 'courseid', get_string('courseid', 'local_data'), $selectArray);    


        $mform->addElement('select', 'clsroomid', get_string('clsroomid', 'local_committee'), $selectArray);
        
        $mform->setDefault('clsroomid', '0');
        $mform->addElement('text', 'clsroomid', get_string('clsroomid', 'local_committee')); // Add elements to your form

        $rssch = $DB->get_recordset_sql('select * from mdl_scheduler');
    
        $selectArrayrssch = array();
       
      // push query results into selectArray as key, value
        foreach($rssch as $rsschid) {
            $key1 =$rsschid->id;
            $value1 = $rsschid->name;
            $selectArrayrssch[$key1] = $value1;
        }

        //$mform->addElement('select', 'courseid', get_string('courseid', 'local_data'), $selectArray);    


        $mform->addElement('select', 'schedulerid', get_string('schedulerid', 'local_committee'), $selectArrayrssch);
        
        $mform->setDefault('schedulerid', '0');
        $mform->addElement('text', 'schedulerid', get_string('schedulerid', 'local_committee')); // Add elements to your form
        
        
        $this->add_action_buttons();
    }
    //Custom validation should be added here
    function validation($data, $files) {
        return array();
    }
}
