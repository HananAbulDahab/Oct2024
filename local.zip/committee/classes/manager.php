<?php


/**
 * @package     local_clsroom
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_committee;

use dml_exception;
use stdClass;

class manager {

    /** Insert the data into our database table.
     * @param string $clsroom_text
     * @param string $clsroom_type
     * @return bool true if successful
     */
    public function create_committee(string $committeetype, string $memberscount, string $clsroomid, string $schedulerid): bool
    {
        global $DB;
        $record_to_insert = new stdClass();
        
        $record_to_insert->memberscount =$memberscount;
        $record_to_insert->committeetype = $committeetype;
        $record_to_insert->committeecoursecatid = 0;
        $record_to_insert->clsroomid = $clsroomid;
        $record_to_insert->schedulerid=$schedulerid;
        
        $record_to_insert->duration = 0;
        $record_to_insert->timefrom= "2024-09-11 13:00:00";
        $record_to_insert->timeto = "2024-09-11 13:00:00";
        $record_to_insert->datefrom = "2024-09-11 13:00:00";
        $record_to_insert->dateto = "2024-09-11 13:00:00";
        
        $record_to_insert->delflag = 0;

        try {
            return $DB->insert_record('local_committee', $record_to_insert, false);
        } catch (dml_exception $e) {
            return false;
        }
    }

    /** Gets all clsrooms >>>
     * @param int $userid the user that we are getting messages for
     * @return array of messages
     */
//    public function get_clsrooms(int $userid): array
//    {
//        global $DB;
//        $sql = "SELECT lm.id, lm.messagetext, lm.messagetype 
//            FROM {local_message} lm 
//            LEFT OUTER JOIN {local_message_read} lmr ON lm.id = lmr.messageid AND lmr.userid = :userid 
//            WHERE lmr.userid IS NULL";
//        $params = [
//            'userid' => $userid,
//        ];
//        try {
//            return $DB->get_records_sql($sql, $params);
//        } catch (dml_exception $e) {
//            // Log error here.
//            return [];
//        }
//    }

    /** Gets all clsrooms
     * @return array of clsrooms
     */
    public function get_all_committee(): array {
        global $DB;
        return $DB->get_records('local_committee',  ['delflag' => 0]);
    }

    /** Mark that a clsroom was read by this user.
     * @param int $clsroom_id the message to mark as read
     * @param int $userid the user that we are marking message read
     * @return bool true if successful
     */
    //public function mark_message_read(int $message_id, int $userid): bool
    //{
    //    global $DB;
    //    $read_record = new stdClass();
    //    $read_record->messageid = $message_id;
    //    $read_record->userid = $userid;
    //    $read_record->timeread = time();
    //    try {
    //        return $DB->insert_record('local_message_read', $read_record, false);
    //    } catch (dml_exception $e) {
    //        return false;
    //    }
    // }

    /** Get a single clsroom from its id.
     * @param int $clsroomid the clsroom we're trying to get.
     * @return object|false clsroom data or false if not found.
     */
    public function get_committee(int $committeeid)
    {
        global $DB;
        return $DB->get_record('local_committee', ['id' => $committeeid]);
    }

    /** Update details for a single clsroom.
     * @param int $clsroomid the clsroom we're trying to get.
     * @param string $clsroom_text the new text for the clsroom.
     * @param string $clsroom_type the new type for the clsroom.
     * @return bool clsroom data or false if not found.
     */
    public function update_committee(int $committeeid, string $committeetype, string $memberscount, string $clsroomid, string $schedulerid): bool
    {
        global $DB;
        $object = new stdClass();
        $object->id = $committeeid;
        $object->committeetype = $committeetype;
        $object->memberscount = $memberscount;
        $object->clsroomcoursecatid=0;
        
        $object->clsroomid = $clsroomid;
        $object->duration = 0;
        
        $object->schedulerid=$schedulerid;
        
        $object->timefrom= "2024-09-11 13:00:00";
        $object->timeto = "2024-09-11 13:00:00";
        $object->datefrom = "2024-09-11 13:00:00";
        $object->dateto = "2024-09-11 13:00:00";
        
        $object->delflag = 0;

        return $DB->update_record('local_committee', $object);
    }
    public function updatedel_committee(int $committeeid, string $committeetype, string $memberscount): bool
    {
        global $DB;
        $object = new stdClass();
        $object->id = $committeeid;
        $object->committeetype = $committeetype;
        $object->memberscount = $memberscount;
        
        $object->delflag=1;
        
        return $DB->update_record('local_committee', $object);
    }

    /** Update the type for an array of clsrooms.
     * @return bool clsroom data or false if not found.
     */
    public function update_committees(array $committeeids, $memberscount): bool
    {
        global $DB;
        
        list($ids, $params) = $DB->get_in_or_equal($clsroomids);
        return $DB->set_field_select('local_committee', 'memberscount', $memberscount, "id $ids", $params);
    }

    /** Delete a clsroom and all the read history.
     * @param $clsroomid
     * @return bool
     * @throws \dml_transaction_exception
     * @throws dml_exception
     */
    public function delete_committee($committeeid)
    {
        global $DB;
        $transaction = $DB->start_delegated_transaction();
        $deletedcommittee = $DB->delete_records('local_committee', ['id' => $committeeid]);
        //$deletedRead = $DB->delete_records('local_message_read', ['messageid' => $messageid]);
        if ($deletedcommittee ) {
            $DB->commit_delegated_transaction($transaction);
        }
        return true;
    }

    /** Delete all clsrooms by id.
     * @param $clsroomids
     * @return bool
     */
    public function delete_committees($committeeids)
    {
        global $DB;
        list($ids, $params) = $DB->get_in_or_equal($committeeids);
        return $DB->set_field_select('local_committee', 'delflag', 1, "id $ids", $params);
        
    }
}