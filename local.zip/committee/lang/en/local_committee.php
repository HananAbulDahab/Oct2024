<?php

/**
 * Strings for component 'local_clsroom', language 'en'
 *
 * @package   local_clsroom
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['pluginname'] = 'Manage committee';
$string['enter_committee'] = 'Please enter a committee';
$string['manage'] = 'Manage committee';
$string['setting_enable'] = 'Enable';
$string['setting_enable_desc'] = 'Disable to stop any committee from this plugin being displayed';
$string['committee_type'] = 'committee type';
$string['committee_text'] = 'committee text';
$string['committee:managecommittee'] = 'Manage committee';
$string['cancelled_form'] = 'You cancelled the committee form';
$string['updated_form'] = 'You updated a committee with title ';
$string['created_form'] = 'You created a committee with title ';
$string['manage_committee'] = 'Manage committee';
$string['delete_committee'] = 'Delete committee';
$string['delete_committee_confirm'] = 'Are you sure you want to delete committee?';
$string['whattodo'] = 'What do you want to do with your selected committee?';
$string['choose_committee'] = 'Choose your committee';
$string['delete_all_selected'] = 'Delete all selected?';
$string['bulk_edit'] = 'Bulk Edit';
$string['bulk_edit_committee'] = 'Bulk edit your committee';
$string['bulk_edit_successful'] = 'Bulk edit successful!';


