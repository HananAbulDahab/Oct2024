<?php

/**
 * Plugin strings are defined here.
 *
 * @package     local_genseatno
 * @category    string
 * @copyright   2024 iqraa <iqraa@iqraa.edu>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Generate seat number';

//$string['pluginname'] = 'genseatno';
$string['manage'] = 'Generate seat no';
$string['setting_enable'] = 'Enable';
$string['setting_enable_desc'] = 'Disable to stop ';
$string['genseatno:view'] = 'Generate seat no';
$string['manage_genseatno'] = 'Generate seat no';



$string['genseatno:managegenseatno'] = 'Generate seat no';


